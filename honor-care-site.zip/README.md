# Honor Care International

De complete zorgoplossing tussen Colombia en Nederland. Statische website (NL/EN/ES) met een kleine Node/Express-server.

## Structuur

```
honor-care-site/
├── public/
│   └── index.html      ← de volledige website (1 bestand)
├── server.js           ← Express-server
├── package.json
└── .gitignore
```

## Online zetten via GitHub + Railway

1. **GitHub**: maak een nieuwe repository aan en upload de hele inhoud van deze map
   (`public/`, `server.js`, `package.json`, `.gitignore`). Upload **niet** `node_modules`.
2. **Railway**: maak een nieuw project → *Deploy from GitHub repo* → kies deze repository.
3. Railway detecteert Node.js automatisch, draait `npm install` en daarna `npm start`.
4. Onder **Settings → Networking → Generate Domain** krijg je een live-URL.
5. Voor `honorcare.com`: voeg in Railway je eigen domein toe en zet bij je domeinprovider
   de DNS (CNAME) zoals Railway aangeeft.

> Na elke wijziging: bestand op GitHub bijwerken → Railway deployt automatisch opnieuw.
> Zie je een oude versie? Hard refreshen (Ctrl/Cmd + Shift + R) om de browsercache te legen.

## Lokaal testen

```bash
npm install
npm start
# open http://localhost:3000
```

## Foto's

De afbeeldingen worden ingeladen via Unsplash (vrij te gebruiken). Eigen foto's gebruiken?
Zet ze in `public/img/` en vervang de URL's in `index.html` (zoek op `images.unsplash.com`).

## Contact

- E-mail: info@honorcare.com
- WhatsApp: +31 6 46 15 01 60
